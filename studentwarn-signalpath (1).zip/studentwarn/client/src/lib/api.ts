import axios from 'axios';

export const api = axios.create({ baseURL: '/api', withCredentials: true });
api.interceptors.response.use((response) => response, (error) => { if (error.response?.data?.message) error.message = error.response.data.message; return Promise.reject(error); });
export const getError = (error: unknown) => error instanceof Error ? error.message : 'Something went wrong. Please try again.';
