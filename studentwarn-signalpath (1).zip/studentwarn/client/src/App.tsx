import { useEffect, useMemo, useState, createContext, useContext } from 'react';
import { Navigate, Route, Routes, useLocation, useNavigate } from 'react-router-dom';
import { api, getError } from './lib/api';
import { Shell } from './components/Shell';
import { LoginPage } from './pages/LoginPage';
import { DashboardPage } from './pages/DashboardPage';
import { StudentProfilePage } from './pages/StudentProfilePage';
import { StudentDashboardPage } from './pages/StudentDashboardPage';
import { AdminPage } from './pages/AdminPage';

export type User = { id:number; name:string; email:string; role:'ADMIN'|'TEACHER'|'STUDENT'; teacherId?:number; studentId?:number };
type AuthContextValue = { user:User|null; loading:boolean; login:(identifier:string,password:string)=>Promise<void>; logout:()=>Promise<void>; error:string };
const AuthContext=createContext<AuthContextValue>(null!);
export const useAuth=()=>useContext(AuthContext);

function AuthProvider({children}:{children:React.ReactNode}){const [user,setUser]=useState<User|null>(null);const [loading,setLoading]=useState(true);const [error,setError]=useState('');useEffect(()=>{api.get('/auth/me').then(r=>setUser(r.data.user)).catch(()=>setUser(null)).finally(()=>setLoading(false));},[]);const value=useMemo(()=>({user,loading,error,login:async(identifier:string,password:string)=>{setError('');try{const r=await api.post('/auth/login',{identifier,password});setUser(r.data.user);}catch(e){const m=getError(e);setError(m);throw e;}},logout:async()=>{await api.post('/auth/logout');setUser(null);}}),[user,loading,error]);return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>}

function Guard({role,children}:{role:User['role'];children:React.ReactNode}){const {user,loading}=useAuth();const location=useLocation();if(loading)return <div className="loading-screen"><div className="brand-mark">S</div><span>Loading your workspace…</span></div>;if(!user)return <Navigate to="/login" state={{from:location.pathname}} replace/>;if(user.role!==role)return <Navigate to={user.role==='ADMIN'?'/admin/dashboard':user.role==='TEACHER'?'/teacher/dashboard':'/student/dashboard'} replace/>;return <Shell>{children}</Shell>}

function AppRoutes(){const {user}=useAuth();return <Routes><Route path="/login" element={user?<Navigate to={user.role==='ADMIN'?'/admin/dashboard':user.role==='TEACHER'?'/teacher/dashboard':'/student/dashboard'} replace/>:<LoginPage/>}/><Route path="/admin/dashboard" element={<Guard role="ADMIN"><DashboardPage role="ADMIN"/></Guard>}/><Route path="/admin/students" element={<Guard role="ADMIN"><AdminPage/></Guard>}/><Route path="/admin/alerts" element={<Guard role="ADMIN"><AdminPage section="alerts"/></Guard>}/><Route path="/admin/thresholds" element={<Guard role="ADMIN"><AdminPage section="thresholds"/></Guard>}/><Route path="/teacher/dashboard" element={<Guard role="TEACHER"><DashboardPage role="TEACHER"/></Guard>}/><Route path="/teacher/students/:id" element={<Guard role="TEACHER"><StudentProfilePage/></Guard>}/><Route path="/student/dashboard" element={<Guard role="STUDENT"><StudentDashboardPage/></Guard>}/><Route path="*" element={<Navigate to={user?(user.role==='ADMIN'?'/admin/dashboard':user.role==='TEACHER'?'/teacher/dashboard':'/student/dashboard'):'/login'} replace/>}/></Routes>}
export default function App(){return <AuthProvider><AppRoutes/></AuthProvider>}
