import { z } from 'zod';

export const loginSchema = z.object({ identifier: z.string().min(3).max(160), password: z.string().min(6).max(100) });
