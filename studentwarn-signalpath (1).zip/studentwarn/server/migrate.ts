import { ensureSchema, closePool } from './db.js';
try { await ensureSchema(); console.log('MySQL schema is ready.'); } finally { await closePool(); }
