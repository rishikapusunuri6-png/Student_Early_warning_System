import { query } from '../db.js';

type Thresholds = { low_max: number; medium_max: number; attendance_healthy: number; attendance_attention: number; attendance_risk: number; alert_cooldown_days: number };

async function thresholds(): Promise<Thresholds> {
  const rows = await query<any[]>(`SELECT low_max, medium_max, attendance_healthy, attendance_attention, attendance_risk, alert_cooldown_days FROM warning_thresholds WHERE id=1`);
  if (rows[0]) return rows[0];
  return { low_max: 29, medium_max: 59, attendance_healthy: 85, attendance_attention: 75, attendance_risk: 65, alert_cooldown_days: 14 };
}

export async function calculateRisk(studentId: number) {
  const t = await thresholds();
  const [attendanceRows, marksRows, assignmentRows, previousMarks] = await Promise.all([
    query<any[]>(`SELECT COUNT(*) total, SUM(status='PRESENT') present, SUM(status='LATE') late FROM attendance WHERE student_id=?`, [studentId]),
    query<any[]>(`SELECT AVG(marks_obtained / maximum_marks * 100) average_marks, SUM(marks_obtained / maximum_marks * 100 < 40) failed_assessments FROM marks WHERE student_id=?`, [studentId]),
    query<any[]>(`SELECT COUNT(*) total, SUM(status='MISSING') missing, SUM(status='SUBMITTED') submitted FROM assignments WHERE student_id=?`, [studentId]),
    query<any[]>(`SELECT AVG(marks_obtained / maximum_marks * 100) previous_average FROM marks WHERE student_id=? AND exam_date < DATE_SUB(CURDATE(), INTERVAL 45 DAY)`, [studentId])
  ]);
  const attendanceTotal = Number(attendanceRows[0]?.total || 0);
  const attendancePct = attendanceTotal ? ((Number(attendanceRows[0].present || 0) + Number(attendanceRows[0].late || 0) * 0.5) / attendanceTotal) * 100 : 0;
  const averageMarks = Number(marksRows[0]?.average_marks || 0);
  const previousAverage = Number(previousMarks[0]?.previous_average || averageMarks);
  const missing = Number(assignmentRows[0]?.missing || 0);
  const assignmentTotal = Number(assignmentRows[0]?.total || 0);
  const failed = Number(marksRows[0]?.failed_assessments || 0);
  let attendanceRisk = 0;
  if (attendanceTotal && attendancePct < t.attendance_risk) attendanceRisk = 30;
  else if (attendanceTotal && attendancePct < t.attendance_attention) attendanceRisk = 20;
  else if (attendanceTotal && attendancePct < t.attendance_healthy) attendanceRisk = 10;
  const decline = previousAverage ? ((previousAverage - averageMarks) / previousAverage) * 100 : 0;
  const academicRisk = decline > 20 ? 30 : decline > 10 ? 20 : decline > 5 ? 10 : 0;
  const assignmentRisk = missing >= 3 ? 20 : missing > 0 ? 10 : 0;
  const assessmentRisk = failed >= 2 ? 20 : failed === 1 ? 10 : 0;
  const score = Math.min(100, attendanceRisk + academicRisk + assignmentRisk + assessmentRisk);
  const level = score > t.medium_max ? 'HIGH' : score > t.low_max ? 'MEDIUM' : 'LOW';
  const reasons: string[] = [];
  if (attendanceTotal && attendanceRisk) reasons.push(`Attendance is ${Math.round(attendancePct)}%, below the ${t.attendance_healthy}% healthy target.`);
  if (academicRisk) reasons.push(`Average marks changed from ${Math.round(previousAverage)}% to ${Math.round(averageMarks)}% (${Math.round(decline)}% decline).`);
  if (assignmentRisk) reasons.push(`${missing} assignment${missing === 1 ? '' : 's'} ${missing === 1 ? 'is' : 'are'} missing.`);
  if (assessmentRisk) reasons.push(`${failed} assessment${failed === 1 ? '' : 's'} below 40% recorded.`);
  if (!reasons.length) reasons.push('Current academic signals are stable or improving.');
  const action = level === 'HIGH' ? 'Schedule a mentor meeting, review attendance, and provide targeted academic support within 14 days.' : level === 'MEDIUM' ? 'Check in with the student, identify blockers, and schedule a follow-up within 14 days.' : 'Continue regular monitoring and reinforce the student’s healthy habits.';
  await query(`INSERT INTO risk_assessments (student_id, risk_score, risk_level, reasons, recommended_action, attendance_pct, average_marks, previous_average) VALUES (?,?,?,?,?,?,?,?)`, [studentId, score, level, JSON.stringify(reasons), action, attendancePct, averageMarks, previousAverage]);
  if (level !== 'LOW') await createAlerts(studentId, level, score, reasons, action, t.alert_cooldown_days);
  return { studentId, score, level, reasons, action, attendancePct, averageMarks, previousAverage, assignmentCompletion: assignmentTotal ? Math.round(((assignmentTotal - missing) / assignmentTotal) * 100) : 0 };
}

async function createAlerts(studentId: number, level: 'MEDIUM' | 'HIGH', score: number, reasons: string[], action: string, cooldownDays: number) {
  const teachers = await query<any[]>(`SELECT DISTINCT tsa.teacher_id, t.user_id FROM teacher_student_assignments tsa JOIN teachers t ON t.id=tsa.teacher_id WHERE tsa.student_id=?`, [studentId]);
  for (const teacher of teachers) {
    const recent = await query<any[]>(`SELECT id, severity FROM alerts WHERE student_id=? AND teacher_id=? AND created_at >= DATE_SUB(NOW(), INTERVAL ? DAY) ORDER BY created_at DESC LIMIT 1`, [studentId, teacher.teacher_id, cooldownDays]);
    if (recent[0] && recent[0].severity === level) continue;
    const title = `${level === 'HIGH' ? 'Early warning' : 'Support signal'} · student needs attention`;
    const message = `${score}/100 — ${reasons.join(' ')} Recommended: ${action}`;
    const result = await query<any>(`INSERT INTO alerts (student_id, teacher_id, severity, title, message) VALUES (?,?,?,?,?)`, [studentId, teacher.teacher_id, level, title, message]);
    await query(`INSERT INTO notifications (user_id, title, message, type) VALUES (?,?,?,'EARLY_WARNING')`, [teacher.user_id, title, message]);
  }
}

export async function latestRisk(studentId: number) {
  const rows = await query<any[]>(`SELECT * FROM risk_assessments WHERE student_id=? ORDER BY calculated_at DESC LIMIT 1`, [studentId]);
  if (!rows[0]) return calculateRisk(studentId);
  const assignmentRows = await query<any[]>(`SELECT COUNT(*) total, SUM(status='MISSING') missing FROM assignments WHERE student_id=?`, [studentId]);
  const total = Number(assignmentRows[0]?.total || 0);
  const missing = Number(assignmentRows[0]?.missing || 0);
  return { studentId, score: rows[0].risk_score, level: rows[0].risk_level, reasons: JSON.parse(rows[0].reasons || '[]'), action: rows[0].recommended_action, attendancePct: Number(rows[0].attendance_pct), averageMarks: Number(rows[0].average_marks), previousAverage: Number(rows[0].previous_average), assignmentCompletion: total ? Math.round(((total - missing) / total) * 100) : 0 };
}
