import mysql, { type Pool, type RowDataPacket, type ResultSetHeader } from 'mysql2/promise';
import fs from 'node:fs/promises';
import path from 'node:path';
import dotenv from 'dotenv';

dotenv.config();
let pool: Pool | null = null;
export function getPool(): Pool { if (!pool) { const url=process.env.DATABASE_URL; if(!url) throw new Error('DATABASE_URL is not configured.'); pool=mysql.createPool({uri:url,waitForConnections:true,connectionLimit:8,decimalNumbers:true}); } return pool; }
export async function query<T extends RowDataPacket[] | ResultSetHeader[]>(sql:string, params:any[]=[]):Promise<T>{const [rows]=await getPool().execute<T>(sql,params);return rows;}
export async function ensureSchema(){const file=await fs.readFile(path.join(process.cwd(),'database/schema.sql'),'utf8');for(const statement of file.split(';').map(s=>s.trim()).filter(Boolean))await getPool().query(statement);}
export async function closePool(){if(pool)await pool.end();pool=null;}
