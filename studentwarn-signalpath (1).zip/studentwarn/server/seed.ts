import bcrypt from 'bcryptjs';
import { closePool, ensureSchema, query } from './db.js';

const passwordHash = await bcrypt.hash('DemoPass!2026', 10);
await ensureSchema();
const existing = await query<any[]>(`SELECT COUNT(*) count FROM users`);
if (Number(existing[0].count) > 0) { console.log('Seed skipped: users already exist.'); await closePool(); process.exit(0); }
const departments = [['Computer Science','CSE'],['Business Administration','BBA'],['Design & Media','DM']];
for (const [name,code] of departments) await query(`INSERT INTO departments(name,code) VALUES (?,?)`,[name,code]);
const departmentIds = await query<any[]>(`SELECT id,code FROM departments`);
for (const d of departmentIds) await query(`INSERT INTO classes(name,department_id,academic_year) VALUES (?,?,?)`,[`Year 2 · ${d.code}`,d.id,'2026-27']);
const subjects = [['Data Structures','DSA'],['Database Systems','DBS'],['Communication Skills','COM'],['Applied Statistics','STA'],['Product Studio','PST']];
for (const [name,code] of subjects) await query(`INSERT INTO subjects(name,code,credits) VALUES (?,?,3)`,[name,code]);
const subjectRows=await query<any[]>(`SELECT id FROM subjects`); const classRows=await query<any[]>(`SELECT id,department_id FROM classes`);
const admin=await query<any>(`INSERT INTO users(name,email,password_hash,role) VALUES ('Asha Mehta','admin@example.com',?,'ADMIN')`,[passwordHash]);
for(let i=1;i<=5;i++){const u=await query<any>(`INSERT INTO users(name,email,password_hash,role) VALUES (?,?,?,'TEACHER')`,[`Teacher ${i}`,`teacher${i}@example.com`,passwordHash]);const dept=departmentIds[(i-1)%departmentIds.length];await query(`INSERT INTO teachers(user_id,employee_id,department_id) VALUES (?,?,?)`,[u.insertId,`TCH-${String(i).padStart(3,'0')}`,dept.id]);}
const teacherRows=await query<any[]>(`SELECT id,user_id FROM teachers ORDER BY id`);
for(const t of teacherRows) for(const s of subjectRows.slice(0,3)) await query(`INSERT IGNORE INTO teacher_subjects(teacher_id,subject_id) VALUES (?,?)`,[t.id,s.id]);
for(let i=1;i<=50;i++){const dept=departmentIds[(i-1)%departmentIds.length];const cls=classRows.find((c)=>c.department_id===dept.id)||classRows[0];const u=await query<any>(`INSERT INTO users(name,email,password_hash,role) VALUES (?,?,?,'STUDENT')`,[`Student ${i}`,`student${i}@example.com`,passwordHash]);const s=await query<any>(`INSERT INTO students(user_id,student_id,department_id,class_id,semester,enrollment_date) VALUES (?,?,?,?,4,'2025-08-01')`,[u.insertId,`STU-${String(i).padStart(4,'0')}`,dept.id,cls.id]);const teacher=teacherRows[(i-1)%teacherRows.length];await query(`INSERT INTO teacher_student_assignments(teacher_id,student_id,assignment_type) VALUES (?,?,'MENTOR')`,[teacher.id,s.insertId]);for(const sub of subjectRows.slice(0,4)){const profile=i%6;const base=profile===0?82:profile===1?68:profile===2?52:profile===3?62:profile===4?78:42;for(let e=0;e<3;e++){const value=Math.max(20,Math.min(98,base+(profile===2?-e*9:e*2)+(i%5)));await query(`INSERT INTO marks(student_id,subject_id,exam_type,exam_name,marks_obtained,maximum_marks,exam_date,created_by) VALUES (?,?, 'INTERNAL', ?, ?, 100, DATE_SUB(CURDATE(),INTERVAL ? DAY), ?)`,[s.insertId,sub.id,`Assessment ${e+1}`,value,(2-e)*30,u.insertId]);for(let day=1;day<=10;day++) await query(`INSERT IGNORE INTO attendance(student_id,subject_id,date,status,recorded_by) VALUES (?,?,DATE_SUB(CURDATE(),INTERVAL ? DAY),?,?)`,[s.insertId,sub.id,day,(profile===4&&day%4===0)?'ABSENT':(profile>=2&&day%3===0?'ABSENT':'PRESENT'),u.insertId]);await query(`INSERT INTO assignments(student_id,subject_id,assignment_name,status,score,maximum_score,due_date) VALUES (?,?,?, ?, ?,100,DATE_ADD(CURDATE(),INTERVAL ? DAY))`,[s.insertId,sub.id,`Weekly brief ${e+1}`,profile===0||profile===1||e<1?'SUBMITTED':'MISSING',profile===0||profile===1?80:null,e+2]);}}
}
await query(`INSERT INTO warning_thresholds(id) VALUES (1) ON DUPLICATE KEY UPDATE id=id`);
const students=await query<any[]>(`SELECT id FROM students`); for(const s of students) { const { calculateRisk }=await import('./services/risk.js'); await calculateRisk(s.id); }
console.log('Seed complete: admin@example.com, teacher1@example.com, student1@example.com · password DemoPass!2026'); await closePool();
