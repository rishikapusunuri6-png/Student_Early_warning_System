import type { NextFunction, Request, Response } from 'express';
import jwt from 'jsonwebtoken';
import { query } from '../db.js';
export type Role='ADMIN'|'TEACHER'|'STUDENT';
export type AuthUser={id:number;name:string;email:string;role:Role;status:string;teacherId?:number;studentId?:number};
declare global{namespace Express{interface Request{user?:AuthUser}}}

export function getJwtSecret(){
  const value=process.env.JWT_SECRET;
  if(process.env.NODE_ENV==='production' && (!value || value.length<32)) throw new Error('JWT_SECRET must be at least 32 characters in production.');
  return value || 'dev-only-change-me';
}
export function validateSecurityConfig(){
  if(process.env.NODE_ENV==='production') {
    getJwtSecret();
    if(!allowedOrigins().length) throw new Error('CLIENT_ORIGIN must be configured in production.');
  }
}
export function allowedOrigins(){return [process.env.CLIENT_ORIGIN,process.env.PREVIEW_ORIGIN].filter((v):v is string=>Boolean(v)).map(v=>v.replace(/\/$/,''));}
export function isAllowedOrigin(origin?:string){return !origin || allowedOrigins().includes(origin.replace(/\/$/,'')) || (process.env.NODE_ENV!=='production' && !allowedOrigins().length);}
export function signToken(user:AuthUser){return jwt.sign({sub:user.id,role:user.role},getJwtSecret(),{expiresIn:(process.env.JWT_EXPIRES_IN||'8h') as any});}
export function setSession(res:Response,token:string){const localHttp=process.env.LOCAL_HTTP==='true';res.cookie('sweg_session',token,{httpOnly:true,sameSite:localHttp?'lax':'none',secure:!localHttp,maxAge:8*60*60*1000,path:'/'});}
export async function requireAuth(req:Request,res:Response,next:NextFunction){try{const raw=req.cookies?.sweg_session||(req.headers.authorization?.startsWith('Bearer ')?req.headers.authorization.slice(7):undefined);if(!raw)return res.status(401).json({message:'Please sign in to continue.'});const payload=jwt.verify(raw,getJwtSecret()) as jwt.JwtPayload;const users=await query<any[]>(`SELECT u.id,u.name,u.email,u.role,u.status,t.id AS teacherId,s.id AS studentId FROM users u LEFT JOIN teachers t ON t.user_id=u.id LEFT JOIN students s ON s.user_id=u.id WHERE u.id=? AND u.status='ACTIVE' LIMIT 1`,[payload.sub]);if(!users[0])return res.status(401).json({message:'Your account is inactive or no longer exists.'});req.user=users[0] as AuthUser;next();}catch{return res.status(401).json({message:'Your session has expired. Please sign in again.'});}}
export function requireRole(...roles:Role[]){return(req:Request,res:Response,next:NextFunction)=>{if(!req.user||!roles.includes(req.user.role))return res.status(403).json({message:'You do not have permission to access this area.'});next();};}
